# VictoriaMetrics data source for Grafana

The VictoriaMetrics data source plugin allows you to query and visualize VictoriaMetrics
data from within Grafana.

Read more about it here:

[https://docs.victoriametrics.com/](https://docs.victoriametrics.com/)
